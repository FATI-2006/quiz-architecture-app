from flask import Flask, render_template, request, redirect, url_for, session, flash
import random
import hashlib
from datetime import datetime

app = Flask(__name__)
app.secret_key = 'quiz_architecture_secret_2024'

# ─────────────────────────────────────────
#  Données utilisateurs (stockage en mémoire)
#  Pour passer à SQLite : remplacer par SQLAlchemy
# ─────────────────────────────────────────
users = {}       # { username: { email, password_hash, scores, attempts } }
user_questions = []  # Questions proposées par les étudiants (bonus)


# ─────────────────────────────────────────
#  Import des questions depuis data/questions.py
# ─────────────────────────────────────────
from data.questions import QUESTIONS


# ─────────────────────────────────────────
#  Utilitaires
# ─────────────────────────────────────────
def hash_password(password):
    """Hash simple SHA-256 pour stocker le mot de passe."""
    return hashlib.sha256(password.encode()).hexdigest()


def get_user(username):
    """Retourne les données d'un utilisateur ou None."""
    return users.get(username)


def is_logged_in():
    """Vérifie si un utilisateur est connecté via la session."""
    return 'username' in session


def login_required(f):
    """Décorateur : redirige vers login si non connecté."""
    from functools import wraps
    @wraps(f)
    def decorated(*args, **kwargs):
        if not is_logged_in():
            flash("Veuillez vous connecter pour accéder à cette page.", "warning")
            return redirect(url_for('login'))
        return f(*args, **kwargs)
    return decorated


# ─────────────────────────────────────────
#  Routes principales
# ─────────────────────────────────────────

@app.route('/')
def index():
    """Page d'accueil."""
    categories = list(QUESTIONS.keys())
    return render_template('index.html', categories=categories, logged_in=is_logged_in())


# ─── Authentification ───────────────────

@app.route('/register', methods=['GET', 'POST'])
def register():
    """Inscription d'un nouvel utilisateur."""
    if is_logged_in():
        return redirect(url_for('dashboard'))

    if request.method == 'POST':
        username = request.form.get('username', '').strip()
        email    = request.form.get('email', '').strip()
        password = request.form.get('password', '')
        confirm  = request.form.get('confirm_password', '')

        # Validations
        if not username or not email or not password:
            flash("Tous les champs sont obligatoires.", "danger")
        elif username in users:
            flash("Ce nom d'utilisateur est déjà pris.", "danger")
        elif password != confirm:
            flash("Les mots de passe ne correspondent pas.", "danger")
        elif len(password) < 4:
            flash("Le mot de passe doit contenir au moins 4 caractères.", "danger")
        else:
            users[username] = {
                'email': email,
                'password_hash': hash_password(password),
                'scores': {},       # { categorie: [liste de scores] }
                'attempts': {},     # { categorie: nombre_de_tentatives }
                'created_at': datetime.now().strftime('%d/%m/%Y')
            }
            session['username'] = username
            flash(f"Bienvenue {username} ! Votre compte a été créé.", "success")
            return redirect(url_for('dashboard'))

    return render_template('register.html')


@app.route('/login', methods=['GET', 'POST'])
def login():
    """Connexion d'un utilisateur existant."""
    if is_logged_in():
        return redirect(url_for('dashboard'))

    if request.method == 'POST':
        username = request.form.get('username', '').strip()
        password = request.form.get('password', '')

        user = get_user(username)
        if user and user['password_hash'] == hash_password(password):
            session['username'] = username
            flash(f"Bon retour, {username} !", "success")
            return redirect(url_for('dashboard'))
        else:
            flash("Nom d'utilisateur ou mot de passe incorrect.", "danger")

    return render_template('login.html')


@app.route('/logout')
def logout():
    """Déconnexion."""
    username = session.pop('username', None)
    if username:
        flash(f"À bientôt, {username} !", "info")
    return redirect(url_for('index'))


# ─── Espace utilisateur ─────────────────

@app.route('/dashboard')
@login_required
def dashboard():
    """Tableau de bord personnel de l'utilisateur."""
    username = session['username']
    user     = get_user(username)
    categories = list(QUESTIONS.keys())

    # Calcul du score total (meilleur score par catégorie)
    total_score = 0
    best_scores = {}
    for cat, score_list in user['scores'].items():
        if score_list:
            best = max(score_list)
            best_scores[cat] = best
            total_score += best

    # Nombre de tentatives par catégorie
    attempts = user.get('attempts', {})

    return render_template(
        'dashboard.html',
        username=username,
        email=user['email'],
        categories=categories,
        best_scores=best_scores,
        total_score=total_score,
        attempts=attempts,
        created_at=user.get('created_at', '')
    )


# ─── Quiz ───────────────────────────────

MAX_ATTEMPTS = 3   # Bonus : limite de tentatives par catégorie

@app.route('/quiz/<categorie>', methods=['GET'])
@login_required
def quiz(categorie):
    """Lance un quiz pour une catégorie donnée."""
    if categorie not in QUESTIONS:
        flash("Catégorie introuvable.", "danger")
        return redirect(url_for('dashboard'))

    username = session['username']
    user     = get_user(username)

    # Vérification du nombre de tentatives (bonus)
    attempts = user['attempts'].get(categorie, 0)
    if attempts >= MAX_ATTEMPTS:
        flash(f"Vous avez atteint la limite de {MAX_ATTEMPTS} tentatives pour cette catégorie.", "warning")
        return redirect(url_for('dashboard'))

    # Sélection aléatoire de 10 questions
    pool      = QUESTIONS[categorie]
    questions = random.sample(pool, min(10, len(pool)))

    # Stockage dans la session pour la soumission
    session['quiz_categorie']  = categorie
    session['quiz_questions']  = questions
    session['quiz_start_time'] = datetime.now().isoformat()

    return render_template(
        'quiz.html',
        categorie=categorie,
        questions=questions,
        total=len(questions),
        time_limit=300   # 5 minutes (bonus timer)
    )


@app.route('/quiz/<categorie>/submit', methods=['POST'])
@login_required
def submit_quiz(categorie):
    """Traite les réponses soumises et calcule le score."""
    username  = session['username']
    user      = get_user(username)
    questions = session.get('quiz_questions', [])

    if not questions or session.get('quiz_categorie') != categorie:
        flash("Session de quiz invalide.", "danger")
        return redirect(url_for('dashboard'))

    score   = 0
    details = []   # Pour afficher le corrigé

    for i, question in enumerate(questions):
        correct_answers = set(question['answers'])
        field_name      = f"question_{i}"

        # Récupération des réponses cochées (checkbox ou radio)
        submitted = set(request.form.getlist(field_name))

        is_correct = (submitted == correct_answers)
        if is_correct:
            score += 2   # 2 points par question

        details.append({
            'question':         question['question'],
            'choices':          question['choices'],
            'correct_answers':  correct_answers,
            'submitted':        submitted,
            'is_correct':       is_correct
        })

    # Sauvegarde du score
    if categorie not in user['scores']:
        user['scores'][categorie] = []
    user['scores'][categorie].append(score)

    # Incrémentation des tentatives (bonus)
    user['attempts'][categorie] = user['attempts'].get(categorie, 0) + 1

    # Nettoyage de la session quiz
    session.pop('quiz_questions', None)
    session.pop('quiz_categorie', None)
    session.pop('quiz_start_time', None)

    passed  = score >= 10
    max_score = len(questions) * 2   # 20 points maximum

    return render_template(
        'result.html',
        categorie=categorie,
        score=score,
        max_score=max_score,
        passed=passed,
        details=details,
        attempts=user['attempts'][categorie],
        max_attempts=MAX_ATTEMPTS
    )


# ─── Bonus : Contribution de questions ──

@app.route('/contribute', methods=['GET', 'POST'])
@login_required
def contribute():
    """Permet à un utilisateur de proposer une nouvelle question."""
    categories = list(QUESTIONS.keys())

    if request.method == 'POST':
        categorie = request.form.get('categorie', '').strip()
        question  = request.form.get('question', '').strip()
        choice_a  = request.form.get('choice_a', '').strip()
        choice_b  = request.form.get('choice_b', '').strip()
        choice_c  = request.form.get('choice_c', '').strip()
        choice_d  = request.form.get('choice_d', '').strip()
        correct   = request.form.getlist('correct')   # cases cochées

        # Validations basiques
        if not all([categorie, question, choice_a, choice_b, correct]):
            flash("Veuillez remplir tous les champs obligatoires et indiquer au moins une bonne réponse.", "danger")
        elif categorie not in categories:
            flash("Catégorie invalide.", "danger")
        else:
            new_q = {
                'author':    session['username'],
                'categorie': categorie,
                'question':  question,
                'choices':   [c for c in [choice_a, choice_b, choice_c, choice_d] if c],
                'answers':   correct,
                'submitted_at': datetime.now().strftime('%d/%m/%Y %H:%M')
            }
            user_questions.append(new_q)

            # Ajout direct à la banque de questions
            QUESTIONS[categorie].append({
                'question': question,
                'choices':  new_q['choices'],
                'answers':  correct,
                'type':     'multiple' if len(correct) > 1 else 'single'
            })

            flash("Merci ! Votre question a été ajoutée à la banque.", "success")
            return redirect(url_for('dashboard'))

    return render_template('contribute.html', categories=categories)


# ─────────────────────────────────────────
#  Lancement de l'application
# ─────────────────────────────────────────
if __name__ == '__main__':
    app.run(debug=True)