# data/questions.py
# Banque de questions pour le Quiz d'Architecture
# Chaque question contient :
#   - question  : l'intitulé
#   - choices   : liste des choix proposés
#   - answers   : liste des bonnes réponses (valeurs exactes des choices)
#   - type      : 'single' (une seule réponse) ou 'multiple' (plusieurs réponses)

QUESTIONS = {

    # ─────────────────────────────────────────────────────────
    #  1. Ordres classiques
    # ─────────────────────────────────────────────────────────
    "Ordres classiques": [
        {
            "question": "Quel ordre grec se caractérise par un chapiteau simple sans décoration ?",
            "choices": ["Dorique", "Ionique", "Corinthien", "Toscan"],
            "answers": ["Dorique"],
            "type": "single"
        },
        {
            "question": "L'ordre Ionique se reconnaît notamment à ses :",
            "choices": ["Volutes en spirale", "Feuilles d'acanthe", "Triglyphes et métopes", "Cannelures plates"],
            "answers": ["Volutes en spirale"],
            "type": "single"
        },
        {
            "question": "Quel est l'ordre grec le plus ornemental ?",
            "choices": ["Dorique", "Ionique", "Corinthien", "Composite"],
            "answers": ["Corinthien"],
            "type": "single"
        },
        {
            "question": "Les feuilles d'acanthe ornent le chapiteau de quel ordre ?",
            "choices": ["Dorique", "Ionique", "Corinthien", "Toscan"],
            "answers": ["Corinthien"],
            "type": "single"
        },
        {
            "question": "Quels ordres sont d'origine grecque ? (plusieurs réponses)",
            "choices": ["Dorique", "Toscan", "Ionique", "Corinthien"],
            "answers": ["Dorique", "Ionique", "Corinthien"],
            "type": "multiple"
        },
        {
            "question": "L'entablement comprend quels éléments ? (plusieurs réponses)",
            "choices": ["L'architrave", "La frise", "La corniche", "Le stylobate"],
            "answers": ["L'architrave", "La frise", "La corniche"],
            "type": "multiple"
        },
        {
            "question": "Le Parthénon d'Athènes utilise principalement quel ordre ?",
            "choices": ["Dorique", "Ionique", "Corinthien", "Composite"],
            "answers": ["Dorique"],
            "type": "single"
        },
        {
            "question": "L'ordre Toscan est une version simplifiée de quel ordre grec ?",
            "choices": ["Ionique", "Dorique", "Corinthien", "Composite"],
            "answers": ["Dorique"],
            "type": "single"
        },
        {
            "question": "Le stylobate désigne :",
            "choices": [
                "La plateforme sur laquelle reposent les colonnes",
                "Le chapiteau de la colonne",
                "La partie supérieure de la frise",
                "L'ensemble des marches du temple"
            ],
            "answers": ["La plateforme sur laquelle reposent les colonnes"],
            "type": "single"
        },
        {
            "question": "Quelle est la particularité des colonnes doriques par rapport aux ioniques ?",
            "choices": [
                "Elles n'ont pas de base",
                "Elles sont plus élancées",
                "Elles ont des volutes",
                "Elles sont toujours en marbre blanc"
            ],
            "answers": ["Elles n'ont pas de base"],
            "type": "single"
        },
        {
            "question": "Les triglyphes et métopes appartiennent à la frise de quel ordre ?",
            "choices": ["Dorique", "Ionique", "Corinthien", "Composite"],
            "answers": ["Dorique"],
            "type": "single"
        },
    ],

    # ─────────────────────────────────────────────────────────
    #  2. Architecture moderne
    # ─────────────────────────────────────────────────────────
    "Architecture moderne": [
        {
            "question": "Qui est le fondateur de l'école du Bauhaus ?",
            "choices": ["Walter Gropius", "Le Corbusier", "Mies van der Rohe", "Frank Lloyd Wright"],
            "answers": ["Walter Gropius"],
            "type": "single"
        },
        {
            "question": "Les '5 points de l'architecture' ont été formulés par :",
            "choices": ["Le Corbusier", "Gropius", "Aalto", "Kahn"],
            "answers": ["Le Corbusier"],
            "type": "single"
        },
        {
            "question": "Lesquels font partie des 5 points de Le Corbusier ? (plusieurs réponses)",
            "choices": ["Les pilotis", "Le toit-terrasse", "Les murs en pierre", "Le plan libre"],
            "answers": ["Les pilotis", "Le toit-terrasse", "Le plan libre"],
            "type": "multiple"
        },
        {
            "question": "La Villa Savoye est une œuvre de :",
            "choices": ["Le Corbusier", "Mies van der Rohe", "Alvar Aalto", "Louis Kahn"],
            "answers": ["Le Corbusier"],
            "type": "single"
        },
        {
            "question": "La devise 'Less is more' est associée à :",
            "choices": ["Mies van der Rohe", "Le Corbusier", "Frank Lloyd Wright", "Zaha Hadid"],
            "answers": ["Mies van der Rohe"],
            "type": "single"
        },
        {
            "question": "Le Bauhaus était une école établie dans quelle ville allemande à l'origine ?",
            "choices": ["Weimar", "Berlin", "Munich", "Hambourg"],
            "answers": ["Weimar"],
            "type": "single"
        },
        {
            "question": "Le mouvement 'Organic Architecture' est associé à :",
            "choices": ["Frank Lloyd Wright", "Le Corbusier", "Walter Gropius", "Oscar Niemeyer"],
            "answers": ["Frank Lloyd Wright"],
            "type": "single"
        },
        {
            "question": "Fallingwater est une maison suspendue au-dessus d'une cascade, conçue par :",
            "choices": ["Frank Lloyd Wright", "Mies van der Rohe", "Philip Johnson", "Eero Saarinen"],
            "answers": ["Frank Lloyd Wright"],
            "type": "single"
        },
        {
            "question": "Qui a conçu le Pavillon Allemand de Barcelone (1929) ?",
            "choices": ["Mies van der Rohe", "Le Corbusier", "Walter Gropius", "Hugo Häring"],
            "answers": ["Mies van der Rohe"],
            "type": "single"
        },
        {
            "question": "L'architecture brutaliste se caractérise par l'utilisation prédominante de :",
            "choices": ["Béton brut", "Verre et acier", "Brique rouge", "Pierre naturelle"],
            "answers": ["Béton brut"],
            "type": "single"
        },
        {
            "question": "Lequel de ces architectes est associé au déconstructivisme ?",
            "choices": ["Zaha Hadid", "Le Corbusier", "Alvar Aalto", "Louis Sullivan"],
            "answers": ["Zaha Hadid"],
            "type": "single"
        },
    ],

    # ─────────────────────────────────────────────────────────
    #  3. Matériaux et Structures
    # ─────────────────────────────────────────────────────────
    "Matériaux et Structures": [
        {
            "question": "Quel matériau est obtenu en mélangeant ciment, eau, sable et gravier ?",
            "choices": ["Béton", "Mortier", "Plâtre", "Chaux"],
            "answers": ["Béton"],
            "type": "single"
        },
        {
            "question": "Le béton armé associe le béton avec quel autre matériau ?",
            "choices": ["Acier", "Bois", "Aluminium", "Cuivre"],
            "answers": ["Acier"],
            "type": "single"
        },
        {
            "question": "Quelles sont les propriétés mécaniques caractéristiques du béton ? (plusieurs réponses)",
            "choices": ["Bonne résistance à la compression", "Faible résistance à la traction", "Bonne résistance à la traction", "Légèreté"],
            "answers": ["Bonne résistance à la compression", "Faible résistance à la traction"],
            "type": "multiple"
        },
        {
            "question": "La voûte en berceau est un système structurel qui travaille principalement en :",
            "choices": ["Compression", "Traction", "Flexion", "Torsion"],
            "answers": ["Compression"],
            "type": "single"
        },
        {
            "question": "Quel est l'avantage principal du bois lamellé-collé ?",
            "choices": [
                "Il permet de grandes portées avec un matériau renouvelable",
                "Il est totalement incombustible",
                "Il est moins coûteux que le béton",
                "Il ne nécessite aucun entretien"
            ],
            "answers": ["Il permet de grandes portées avec un matériau renouvelable"],
            "type": "single"
        },
        {
            "question": "L'arc en plein cintre est caractéristique de quel style architectural ?",
            "choices": ["Roman", "Gothique", "Renaissance", "Baroque"],
            "answers": ["Roman"],
            "type": "single"
        },
        {
            "question": "L'arc brisé (ogival) est caractéristique de quel style ?",
            "choices": ["Gothique", "Roman", "Baroque", "Néoclassique"],
            "answers": ["Gothique"],
            "type": "single"
        },
        {
            "question": "Quels matériaux sont considérés comme biosourcés ? (plusieurs réponses)",
            "choices": ["Paille", "Chanvre", "Béton", "Terre crue"],
            "answers": ["Paille", "Chanvre", "Terre crue"],
            "type": "multiple"
        },
        {
            "question": "Le CLT (Cross-Laminated Timber) est :",
            "choices": [
                "Un panneau de bois massif contrecollé",
                "Un type de béton léger",
                "Un alliage d'acier et d'aluminium",
                "Un isolant thermique en laine de verre"
            ],
            "answers": ["Un panneau de bois massif contrecollé"],
            "type": "single"
        },
        {
            "question": "La Tour Eiffel est principalement construite en :",
            "choices": ["Fer puddlé", "Acier inoxydable", "Béton armé", "Aluminium"],
            "answers": ["Fer puddlé"],
            "type": "single"
        },
        {
            "question": "Quelle est la fonction principale d'un contrefort dans une cathédrale gothique ?",
            "choices": [
                "Contrebalancer la poussée des voûtes",
                "Décorer la façade extérieure",
                "Supporter le clocher",
                "Ventiler l'intérieur de l'édifice"
            ],
            "answers": ["Contrebalancer la poussée des voûtes"],
            "type": "single"
        },
    ],

    # ─────────────────────────────────────────────────────────
    #  4. Monuments célèbres
    # ─────────────────────────────────────────────────────────
    "Monuments célèbres": [
        {
            "question": "La Sagrada Família à Barcelone est l'œuvre de quel architecte ?",
            "choices": ["Antoni Gaudí", "Santiago Calatrava", "Rafael Moneo", "Ricardo Bofill"],
            "answers": ["Antoni Gaudí"],
            "type": "single"
        },
        {
            "question": "Le Colisée de Rome a été construit sous quel empire ?",
            "choices": ["Empire romain", "Empire byzantin", "Empire grec", "Empire ottoman"],
            "answers": ["Empire romain"],
            "type": "single"
        },
        {
            "question": "Le Centre Pompidou à Paris a été conçu par :",
            "choices": ["Renzo Piano et Richard Rogers", "Jean Nouvel", "Norman Foster", "Ieoh Ming Pei"],
            "answers": ["Renzo Piano et Richard Rogers"],
            "type": "single"
        },
        {
            "question": "La Pyramide du Louvre a été réalisée par :",
            "choices": ["Ieoh Ming Pei", "Frank Gehry", "Zaha Hadid", "Norman Foster"],
            "answers": ["Ieoh Ming Pei"],
            "type": "single"
        },
        {
            "question": "Le musée Guggenheim de Bilbao est recouvert de panneaux de :",
            "choices": ["Titane", "Acier inoxydable", "Aluminium", "Cuivre"],
            "answers": ["Titane"],
            "type": "single"
        },
        {
            "question": "Quel architecte a conçu le musée Guggenheim de Bilbao ?",
            "choices": ["Frank Gehry", "Zaha Hadid", "Renzo Piano", "Jean Nouvel"],
            "answers": ["Frank Gehry"],
            "type": "single"
        },
        {
            "question": "L'Opéra de Sydney est une œuvre de :",
            "choices": ["Jørn Utzon", "Oscar Niemeyer", "Kenzo Tange", "Louis Kahn"],
            "answers": ["Jørn Utzon"],
            "type": "single"
        },
        {
            "question": "Le Panthéon de Rome est coiffé d'un dôme avec une ouverture au sommet appelée :",
            "choices": ["Oculus", "Lanternon", "Tholos", "Caissons"],
            "answers": ["Oculus"],
            "type": "single"
        },
        {
            "question": "Lequel de ces monuments est classé au patrimoine mondial de l'UNESCO ? (plusieurs réponses)",
            "choices": ["La Sagrada Família", "Le Taj Mahal", "La Tour Eiffel", "Le Colisée"],
            "answers": ["La Sagrada Família", "Le Taj Mahal", "Le Colisée"],
            "type": "multiple"
        },
        {
            "question": "Le Château de Versailles a été construit principalement sous le règne de :",
            "choices": ["Louis XIV", "Louis XIII", "Louis XVI", "Napoléon Ier"],
            "answers": ["Louis XIV"],
            "type": "single"
        },
        {
            "question": "La Grande Muraille de Chine a été construite principalement pour :",
            "choices": [
                "Défendre les frontières contre les invasions",
                "Délimiter les terres agricoles",
                "Servir de route commerciale",
                "Célébrer l'Empereur"
            ],
            "answers": ["Défendre les frontières contre les invasions"],
            "type": "single"
        },
    ],

    # ─────────────────────────────────────────────────────────
    #  5. Architecture durable
    # ─────────────────────────────────────────────────────────
    "Architecture durable": [
        {
            "question": "Que signifie le sigle HQE ?",
            "choices": [
                "Haute Qualité Environnementale",
                "Haute Qualité Énergétique",
                "Habitat Qualifié Écologique",
                "Haute Qualité d'Exécution"
            ],
            "answers": ["Haute Qualité Environnementale"],
            "type": "single"
        },
        {
            "question": "Un bâtiment 'passif' (passive house) vise principalement à :",
            "choices": [
                "Réduire au maximum ses besoins en chauffage et climatisation",
                "Produire plus d'énergie qu'il n'en consomme",
                "Utiliser uniquement des matériaux naturels",
                "Être entièrement autonome en eau"
            ],
            "answers": ["Réduire au maximum ses besoins en chauffage et climatisation"],
            "type": "single"
        },
        {
            "question": "Un bâtiment à énergie positive (BEPOS) :",
            "choices": [
                "Produit plus d'énergie qu'il n'en consomme",
                "Consomme moins d'énergie qu'un bâtiment passif",
                "N'utilise aucune énergie fossile",
                "Est entièrement construit en matériaux biosourcés"
            ],
            "answers": ["Produit plus d'énergie qu'il n'en consomme"],
            "type": "single"
        },
        {
            "question": "Quels éléments contribuent à l'efficacité énergétique d'un bâtiment ? (plusieurs réponses)",
            "choices": [
                "L'isolation thermique performante",
                "Les vitrages à faible émissivité",
                "L'orientation du bâtiment",
                "La couleur de la façade"
            ],
            "answers": ["L'isolation thermique performante", "Les vitrages à faible émissivité", "L'orientation du bâtiment"],
            "type": "multiple"
        },
        {
            "question": "Le principe de 'toiture végétalisée' contribue à :",
            "choices": [
                "Réduire les îlots de chaleur urbains",
                "Augmenter la résistance structurelle du bâtiment",
                "Remplacer l'isolation thermique classique",
                "Produire de l'électricité solaire"
            ],
            "answers": ["Réduire les îlots de chaleur urbains"],
            "type": "single"
        },
        {
            "question": "La terre crue est utilisée en construction sous quelles formes ? (plusieurs réponses)",
            "choices": ["Adobe (briques séchées)", "Pisé (terre compactée)", "Béton fibré", "Torchis"],
            "answers": ["Adobe (briques séchées)", "Pisé (terre compactée)", "Torchis"],
            "type": "multiple"
        },
        {
            "question": "L'architecture bioclimatique consiste à :",
            "choices": [
                "Tirer parti du climat local pour réduire les besoins énergétiques",
                "Construire uniquement avec des végétaux",
                "Intégrer des panneaux solaires obligatoirement",
                "Utiliser la géothermie comme seule source d'énergie"
            ],
            "answers": ["Tirer parti du climat local pour réduire les besoins énergétiques"],
            "type": "single"
        },
        {
            "question": "Le label LEED est un système de certification environnementale développé :",
            "choices": ["Aux États-Unis", "En France", "En Allemagne", "Au Royaume-Uni"],
            "answers": ["Aux États-Unis"],
            "type": "single"
        },
        {
            "question": "L'économie circulaire appliquée à la construction favorise :",
            "choices": [
                "La réutilisation et le recyclage des matériaux",
                "La construction exclusivement en béton",
                "L'utilisation de matériaux importés",
                "La démolition systématique des bâtiments anciens"
            ],
            "answers": ["La réutilisation et le recyclage des matériaux"],
            "type": "single"
        },
        {
            "question": "Quel est le principal avantage thermique d'une façade à double peau ?",
            "choices": [
                "Créer une lame d'air isolante et réduire les déperditions",
                "Augmenter la surface habitable intérieure",
                "Éliminer le besoin de climatisation",
                "Servir de support aux panneaux photovoltaïques"
            ],
            "answers": ["Créer une lame d'air isolante et réduire les déperditions"],
            "type": "single"
        },
        {
            "question": "La norme RT 2020 en France concerne :",
            "choices": [
                "Les bâtiments à énergie positive",
                "La résistance au feu des structures",
                "L'accessibilité des bâtiments publics",
                "Les règles antisismiques"
            ],
            "answers": ["Les bâtiments à énergie positive"],
            "type": "single"
        },
    ],
}