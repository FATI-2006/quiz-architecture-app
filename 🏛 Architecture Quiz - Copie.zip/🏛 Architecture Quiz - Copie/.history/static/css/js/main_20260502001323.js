// main.js — ArchQuiz
// Auto-dismiss flash messages after 4 seconds
document.addEventListener('DOMContentLoaded', () => {
  const flashes = document.querySelectorAll('.flash');
  flashes.forEach(f => {
    setTimeout(() => {
      f.style.transition = 'opacity 0.4s ease, transform 0.4s ease';
      f.style.opacity = '0';
      f.style.transform = 'translateY(-6px)';
      setTimeout(() => f.remove(), 400);
    }, 4000);
  });
});